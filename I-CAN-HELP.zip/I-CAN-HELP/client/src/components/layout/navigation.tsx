import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, MessageCircle } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { Language, languageNames } from "@/lib/language";

export function Navigation() {
  const [location] = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const openWhatsApp = () => {
    const phoneNumber = "+27722402122";
    const message = "Hi! I'm interested in your services from I CAN HELP website.";
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const scrollToSection = (sectionId: string) => {
    if (location === '/') {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = `/#${sectionId}`;
    }
    setIsOpen(false);
  };

  const NavItems = () => (
    <>
      <button 
        onClick={() => scrollToSection('services')} 
        className="text-gray-700 hover:text-gold-500 font-medium transition-colors"
      >
        {t('nav.services')}
      </button>
      <button 
        onClick={() => scrollToSection('pricing')} 
        className="text-gray-700 hover:text-gold-500 font-medium transition-colors"
      >
        {t('nav.pricing')}
      </button>
      <button 
        onClick={() => scrollToSection('testimonials')} 
        className="text-gray-700 hover:text-gold-500 font-medium transition-colors"
      >
        {t('nav.testimonials')}
      </button>
      <button 
        onClick={() => scrollToSection('contact')} 
        className="text-gray-700 hover:text-gold-500 font-medium transition-colors"
      >
        {t('nav.contact')}
      </button>
    </>
  );

  return (
    <nav className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center">
            <div className="text-2xl font-bold text-gray-900">
              <span className="text-gold-500">I CAN</span> HELP
            </div>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <NavItems />
            
            <Select value={language} onValueChange={(value: Language) => setLanguage(value)}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(languageNames).map(([code, name]) => (
                  <SelectItem key={code} value={code}>
                    {name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={openWhatsApp}
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              WhatsApp
            </Button>
          </div>
          
          <div className="md:hidden">
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col space-y-4 mt-8">
                  <NavItems />
                  
                  <Select value={language} onValueChange={(value: Language) => setLanguage(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(languageNames).map(([code, name]) => (
                        <SelectItem key={code} value={code}>
                          {name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button
                    onClick={openWhatsApp}
                    className="bg-green-500 hover:bg-green-600 text-white w-full"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
