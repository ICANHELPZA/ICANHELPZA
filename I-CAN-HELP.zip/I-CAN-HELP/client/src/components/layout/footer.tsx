import { Link } from "wouter";
import { MessageCircle, Mail, MapPin, Facebook, Linkedin } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export function Footer() {
  const { t } = useLanguage();

  const openWhatsApp = () => {
    const phoneNumber = "+27722402122";
    const message = "Hi! I'm interested in your services from I CAN HELP website.";
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          
          {/* Brand Column */}
          <div className="space-y-4">
            <div className="text-2xl font-bold">
              <span className="text-gold-400">I CAN</span> HELP
            </div>
            <p className="text-gray-400">
              Professional services for job seekers, businesses, musicians, and students across South Africa.
            </p>
            <div className="flex space-x-4">
              <button 
                onClick={openWhatsApp}
                className="text-gray-400 hover:text-gold-400 transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
              </button>
              <a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold-400 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          {/* Services Column */}
          <div>
            <h3 className="font-semibold text-lg mb-4">{t('nav.services')}</h3>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/service/cv-writing" className="hover:text-gold-400 transition-colors">CV Writing</Link></li>
              <li><Link href="/service/job-seeking" className="hover:text-gold-400 transition-colors">Job Seeking Support</Link></li>
              <li><Link href="/service/call-center" className="hover:text-gold-400 transition-colors">Call Center Services</Link></li>
              <li><Link href="/service/music-mentoring" className="hover:text-gold-400 transition-colors">Music Mentoring</Link></li>
              <li><Link href="/service/academic-support" className="hover:text-gold-400 transition-colors">Academic Support</Link></li>
            </ul>
          </div>
          
          {/* Company Column */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => scrollToSection('services')} className="hover:text-gold-400 transition-colors">About Us</button></li>
              <li><button onClick={() => scrollToSection('testimonials')} className="hover:text-gold-400 transition-colors">{t('nav.testimonials')}</button></li>
              <li><button onClick={() => scrollToSection('pricing')} className="hover:text-gold-400 transition-colors">Referral Program</button></li>
              <li><button onClick={() => scrollToSection('contact')} className="hover:text-gold-400 transition-colors">{t('nav.contact')}</button></li>
              <li><a href="#" className="hover:text-gold-400 transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
          
          {/* Contact Column */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Contact Info</h3>
            <div className="space-y-2 text-gray-400">
              <p className="flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                icanhelpza@gmail.com
              </p>
              <p className="flex items-center">
                <MessageCircle className="w-4 h-4 mr-2" />
                +27 72 240 2122
              </p>
              <p className="flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                South Africa
              </p>
              <div className="mt-4">
                <p className="text-sm">Available in:</p>
                <p className="text-sm">English, Xhosa, Afrikaans, Sesotho</p>
              </div>
            </div>
          </div>
          
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 I CAN HELP. All rights reserved. | Professional services across South Africa.
          </p>
        </div>
      </div>
    </footer>
  );
}
