import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { MessageCircle, Mail, MapPin } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { InsertInquiry } from "@shared/schema";

export function ContactSection() {
  const { t, language } = useLanguage();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    service: "",
    language: language,
    message: ""
  });

  const submitInquiry = useMutation({
    mutationFn: async (data: InsertInquiry) => {
      const response = await apiRequest("POST", "/api/inquiries", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Thank you for your inquiry. We will contact you within 24 hours."
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        service: "",
        language: language,
        message: ""
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit inquiry. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitInquiry.mutate(formData);
  };

  const openWhatsApp = () => {
    const phoneNumber = "+27722402122";
    const message = "Hi! I'm interested in your services from I CAN HELP website.";
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                {t('contact.title')}
              </h2>
              <p className="text-xl text-gray-600">
                {t('contact.description')}
              </p>
            </div>
            
            <div className="space-y-6">
              {/* WhatsApp */}
              <Card 
                className="bg-green-50 hover:bg-green-100 transition-colors cursor-pointer"
                onClick={openWhatsApp}
              >
                <CardContent className="p-4 flex items-center space-x-4">
                  <div className="bg-green-500 rounded-lg p-3">
                    <MessageCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">WhatsApp</h3>
                    <p className="text-gray-600">+27 72 240 2122</p>
                    <p className="text-sm text-green-600">Click to start chatting</p>
                  </div>
                </CardContent>
              </Card>
              
              {/* Email */}
              <Card className="bg-blue-50">
                <CardContent className="p-4 flex items-center space-x-4">
                  <div className="bg-blue-500 rounded-lg p-3">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Email</h3>
                    <p className="text-gray-600">icanhelpza@gmail.com</p>
                    <p className="text-sm text-blue-600">We respond within 24 hours</p>
                  </div>
                </CardContent>
              </Card>
              
              {/* Languages Supported */}
              <Card className="bg-gold-50">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-900 mb-3">Languages We Support</h3>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-gold-100 text-gold-800 px-3 py-1 rounded-full text-sm">English</span>
                    <span className="bg-gold-100 text-gold-800 px-3 py-1 rounded-full text-sm">Xhosa</span>
                    <span className="bg-gold-100 text-gold-800 px-3 py-1 rounded-full text-sm">Afrikaans</span>
                    <span className="bg-gold-100 text-gold-800 px-3 py-1 rounded-full text-sm">Sesotho</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          {/* Contact Form */}
          <Card className="bg-gray-50">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Book a Consultation</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">{t('contact.form.firstName')}</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => updateFormData('firstName', e.target.value)}
                      placeholder="Enter your first name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="lastName">{t('contact.form.lastName')}</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => updateFormData('lastName', e.target.value)}
                      placeholder="Enter your last name"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="email">{t('contact.form.email')}</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateFormData('email', e.target.value)}
                    placeholder="your@email.com"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="phone">{t('contact.form.phone')}</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => updateFormData('phone', e.target.value)}
                    placeholder="+27 XX XXX XXXX"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="service">{t('contact.form.service')}</Label>
                  <Select value={formData.service} onValueChange={(value) => updateFormData('service', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cv-writing">CV Writing & Job Seeking</SelectItem>
                      <SelectItem value="call-center">Call Center Services</SelectItem>
                      <SelectItem value="music-starter">Music: Starter Package (R300)</SelectItem>
                      <SelectItem value="music-pro">Music: Artist Pro Package (R600)</SelectItem>
                      <SelectItem value="music-label">Music: Label Starter (R1500)</SelectItem>
                      <SelectItem value="music-addons">Music: Add-on Services</SelectItem>
                      <SelectItem value="homework-hero">Homework Hero (R100/week)</SelectItem>
                      <SelectItem value="smart-learner">Smart Learner (R250/week)</SelectItem>
                      <SelectItem value="exam-booster">Exam Booster (R350/week)</SelectItem>
                      <SelectItem value="all-in-scholar">All-in Scholar (R500/week)</SelectItem>
                      <SelectItem value="tutor-standby">Tutor on Standby (R40/session)</SelectItem>
                      <SelectItem value="tutor-application">Tutor Application</SelectItem>
                      <SelectItem value="multiple">Multiple Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="language">{t('contact.form.language')}</Label>
                  <Select value={formData.language} onValueChange={(value) => updateFormData('language', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="xh">Xhosa</SelectItem>
                      <SelectItem value="af">Afrikaans</SelectItem>
                      <SelectItem value="st">Sesotho</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="message">{t('contact.form.message')}</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => updateFormData('message', e.target.value)}
                    placeholder="Tell us about your needs..."
                    rows={4}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-gold-500 hover:bg-gold-600 text-black py-3 rounded-lg font-semibold text-lg transition-colors"
                  disabled={submitInquiry.isPending}
                >
                  {submitInquiry.isPending ? "Submitting..." : t('contact.form.submit')}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
