import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export function PricingSection() {
  const { t } = useLanguage();

  const openWhatsApp = () => {
    const phoneNumber = "+27722402122";
    const message = "Hi! I'm interested in your pricing plans from I CAN HELP website.";
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const learnerPackages = [
    {
      id: "homework-hero",
      title: "Homework Hero",
      price: "R100",
      period: "per week",
      features: [
        "WhatsApp homework help",
        "Explanations in English, Xhosa, Zulu, or Afrikaans",
        "Quick response support"
      ],
      popular: false,
      category: "learner"
    },
    {
      id: "smart-learner",
      title: "Smart Learner",
      price: "R250",
      period: "per week or R900/month",
      features: [
        "Homework help",
        "2x Live tutoring sessions/week (30 mins each)",
        "Study schedule template"
      ],
      popular: true,
      category: "learner"
    },
    {
      id: "exam-booster",
      title: "Exam Booster",
      price: "R350",
      period: "per week or R1200/month",
      features: [
        "Everything in Smart Learner",
        "Weekly mock tests & past papers",
        "Revision notes + audio explanations"
      ],
      popular: false,
      category: "learner"
    },
    {
      id: "all-in-scholar",
      title: "All-in Scholar",
      price: "R500",
      period: "per week or R1800/month",
      features: [
        "Full support (Homework + Live Tutoring + Assignments)",
        "3 live sessions/week + parent feedback",
        "Study kit PDF included",
        "Reading sessions"
      ],
      popular: false,
      category: "learner"
    }
  ];

  const businessPlans = [
    {
      id: "weekly",
      title: t('pricing.weekly'),
      price: "R100",
      period: "per week",
      features: [
        "Basic consultation",
        "WhatsApp support", 
        "1 service focus",
        "Email follow-up"
      ],
      popular: false,
      category: "business"
    },
    {
      id: "monthly", 
      title: t('pricing.monthly'),
      price: "R6000",
      period: "per month",
      features: [
        "Comprehensive support",
        "24/7 WhatsApp access",
        "Multiple services", 
        "Priority support",
        "Progress tracking"
      ],
      popular: false,
      category: "business"
    },
    {
      id: "custom",
      title: t('pricing.custom'),
      price: "Custom",
      period: "tailored to you",
      features: [
        "Specialized services",
        "Business packages",
        "Long-term partnerships",
        "Volume discounts"
      ],
      popular: false,
      category: "business"
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Pricing Packages
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Affordable packages designed for learners and businesses across South Africa.
          </p>
        </div>
        
        {/* Learner Support Packages */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-2">
            Learner Support Packages
          </h3>
          <p className="text-lg text-gray-600 text-center mb-12">
            Affordable, flexible, and designed for real results
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {learnerPackages.map((plan) => (
              <Card 
                key={plan.id} 
                className={`relative ${
                  plan.popular 
                    ? 'bg-blue-50 border-2 border-blue-500' 
                    : 'bg-white border-2 border-gray-200 hover:border-blue-500'
                } transition-colors`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardContent className="p-6 text-center">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">
                    {plan.title}
                  </h4>
                  <div className="text-3xl font-bold text-blue-500 mb-2">
                    {plan.price}
                  </div>
                  <div className="text-gray-600 mb-6 text-sm">
                    {plan.period}
                  </div>
                  <ul className="space-y-2 text-left mb-6 text-sm">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="w-4 h-4 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={openWhatsApp}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold transition-colors text-sm"
                    size="sm"
                  >
                    Choose {plan.title}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {/* Tutor on Standby */}
          <div className="mt-12 bg-green-50 rounded-2xl p-8">
            <h4 className="text-2xl font-bold text-gray-900 text-center mb-6">
              🧑‍🏫 TUTOR ON STANDBY
            </h4>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h5 className="text-lg font-semibold text-gray-900 mb-4">✅ For Learners:</h5>
                <p className="text-gray-700 mb-4">
                  Need help NOW? We'll connect you to a verified tutor on standby, 7 days a week (8am–8pm).
                </p>
                <ul className="space-y-2 text-gray-700 mb-4">
                  <li>• Ask urgent questions</li>
                  <li>• Get last-minute exam help</li>
                  <li>• Get help in your home language</li>
                </ul>
                <div className="bg-white rounded-lg p-4 mb-4">
                  <div className="text-2xl font-bold text-green-600">R40</div>
                  <div className="text-sm text-gray-600">per urgent session (up to 20 minutes)</div>
                </div>
                <Button 
                  onClick={openWhatsApp}
                  className="bg-green-500 hover:bg-green-600 text-white"
                >
                  WhatsApp "HELP NOW" to 072 240 2122
                </Button>
              </div>
              
              <div>
                <h5 className="text-lg font-semibold text-gray-900 mb-4">✅ For Tutors (Join the Team):</h5>
                <p className="text-gray-700 mb-4">
                  We are accepting tutors from anywhere in SA who can:
                </p>
                <ul className="space-y-2 text-gray-700 mb-4">
                  <li>• Teach in their language (English, Xhosa, Afrikaans, etc.)</li>
                  <li>• Have experience or passion for tutoring</li>
                  <li>• Be available for quick sessions when needed</li>
                </ul>
                <div className="bg-white rounded-lg p-4 mb-4">
                  <div className="text-sm text-gray-600">📍 Online | Paid per session | Flexible hours</div>
                </div>
                <Button 
                  onClick={openWhatsApp}
                  variant="outline"
                  className="border-green-500 text-green-600 hover:bg-green-50"
                >
                  Apply to Become a Tutor
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Music Distribution Services */}
        <div className="mb-20">
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-2">
            I CAN HELP Musicians
          </h3>
          <p className="text-lg text-gray-600 text-center mb-12">
            Independent music distribution & artist support - Get on Spotify via WhatsApp
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-white border-2 border-gray-200 hover:border-purple-500 transition-colors">
              <CardContent className="p-8 text-center">
                <h4 className="text-2xl font-bold text-gray-900 mb-2">
                  Starter Package
                </h4>
                <div className="text-4xl font-bold text-purple-500 mb-4">
                  R300
                </div>
                <div className="text-gray-600 mb-6">
                  once-off
                </div>
                <ul className="space-y-3 text-left mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Upload 1 song to Spotify, Apple Music, YouTube
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Free cover art (basic)
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Promo flyer (WhatsApp ready)
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Optional SAMRO registration (+R100)
                  </li>
                </ul>
                <Button 
                  onClick={openWhatsApp}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold transition-colors"
                >
                  Choose Starter Package
                </Button>
              </CardContent>
            </Card>

            <Card className="relative bg-purple-50 border-2 border-purple-500 transition-colors">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-purple-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  Most Popular
                </span>
              </div>
              <CardContent className="p-8 text-center">
                <h4 className="text-2xl font-bold text-gray-900 mb-2">
                  Artist Pro Package
                </h4>
                <div className="text-4xl font-bold text-purple-500 mb-4">
                  R600
                </div>
                <div className="text-gray-600 mb-6">
                  once-off
                </div>
                <ul className="space-y-3 text-left mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Upload up to 3 tracks
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Custom cover art for each
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    SAMRO support included
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Artist bio + press release
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    2 promo posters
                  </li>
                </ul>
                <Button 
                  onClick={openWhatsApp}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold transition-colors"
                >
                  Choose Artist Pro
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white border-2 border-gray-200 hover:border-purple-500 transition-colors">
              <CardContent className="p-8 text-center">
                <h4 className="text-2xl font-bold text-gray-900 mb-2">
                  Label Starter
                </h4>
                <div className="text-4xl font-bold text-purple-500 mb-4">
                  R1500
                </div>
                <div className="text-gray-600 mb-6">
                  once-off
                </div>
                <ul className="space-y-3 text-left mb-8">
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    10 songs/month for 3 artists
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Cover design & flyers
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    Monthly royalty reports
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    WhatsApp group support
                  </li>
                  <li className="flex items-center">
                    <Check className="w-5 h-5 text-purple-500 mr-3" />
                    SAMRO + CAPASSO help
                  </li>
                </ul>
                <Button 
                  onClick={openWhatsApp}
                  className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold transition-colors"
                >
                  Choose Label Starter
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Music Add-on Services */}
          <div className="mt-12 bg-purple-50 rounded-2xl p-8">
            <h4 className="text-2xl font-bold text-gray-900 text-center mb-6">
              Add-On Services
            </h4>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg p-4 text-center">
                <h5 className="font-semibold text-gray-900 mb-2">SAMRO Registration</h5>
                <div className="text-2xl font-bold text-purple-600 mb-2">R100</div>
                <div className="text-sm text-gray-600">once-off</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <h5 className="font-semibold text-gray-900 mb-2">Spotify Profile Setup</h5>
                <div className="text-2xl font-bold text-purple-600 mb-2">R50</div>
                <div className="text-sm text-gray-600">once-off</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <h5 className="font-semibold text-gray-900 mb-2">Instagram Reel Promo</h5>
                <div className="text-2xl font-bold text-purple-600 mb-2">R80</div>
                <div className="text-sm text-gray-600">per reel</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <h5 className="font-semibold text-gray-900 mb-2">Music Bio Writing</h5>
                <div className="text-2xl font-bold text-purple-600 mb-2">R70</div>
                <div className="text-sm text-gray-600">per bio</div>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <h5 className="font-semibold text-gray-900 mb-2">Contract Template</h5>
                <div className="text-2xl font-bold text-purple-600 mb-2">R50</div>
                <div className="text-sm text-gray-600">split sheet</div>
              </div>
            </div>
            
            <div className="mt-8 text-center">
              <h5 className="text-lg font-semibold text-gray-900 mb-4">🌟 SPECIAL OFFER</h5>
              <p className="text-gray-700 mb-4">
                🎁 Refer 3 artists = 1 FREE upload<br/>
                💼 Monthly plans available for serious artists
              </p>
              <Button 
                onClick={openWhatsApp}
                className="bg-purple-500 hover:bg-purple-600 text-white"
              >
                Get Started via WhatsApp
              </Button>
            </div>
          </div>
        </div>

        {/* Business Services */}
        <div>
          <h3 className="text-3xl font-bold text-gray-900 text-center mb-2">
            Business Services
          </h3>
          <p className="text-lg text-gray-600 text-center mb-12">
            Professional services for businesses and professionals
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {businessPlans.map((plan) => (
              <Card 
                key={plan.id} 
                className={`relative ${
                  plan.popular 
                    ? 'bg-gold-50 border-2 border-gold-500' 
                    : 'bg-white border-2 border-gray-200 hover:border-gold-500'
                } transition-colors`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gold-500 text-black px-4 py-1 rounded-full text-sm font-semibold">
                      Most Popular
                    </span>
                  </div>
                )}
                <CardContent className="p-8 text-center">
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">
                    {plan.title}
                  </h4>
                  <div className="text-4xl font-bold text-gold-500 mb-4">
                    {plan.price}
                  </div>
                  <div className="text-gray-600 mb-6">
                    {plan.period}
                  </div>
                  <ul className="space-y-3 text-left mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <Check className="w-5 h-5 text-gold-500 mr-3" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    onClick={plan.id === 'custom' ? scrollToContact : openWhatsApp}
                    className={
                      plan.id === 'custom'
                        ? "w-full border-2 border-gold-500 text-gold-600 hover:bg-gold-50 bg-transparent font-semibold transition-colors"
                        : "w-full bg-gold-500 hover:bg-gold-600 text-black font-semibold transition-colors"
                    }
                    variant={plan.id === 'custom' ? 'outline' : 'default'}
                  >
                    {plan.id === 'custom' ? 'Contact Us' : `Choose ${plan.title}`}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        {/* Referral Program Info */}
        <div className="mt-16 bg-gold-50 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Referral Program
          </h3>
          <p className="text-lg text-gray-700 mb-6">
            Refer 3 friends and get 1 week of services absolutely free! 
            Help your community while saving money.
          </p>
          <Button 
            onClick={scrollToContact}
            className="bg-gold-500 hover:bg-gold-600 text-black font-semibold transition-colors"
          >
            Learn More About Referrals
          </Button>
        </div>
      </div>
    </section>
  );
}
