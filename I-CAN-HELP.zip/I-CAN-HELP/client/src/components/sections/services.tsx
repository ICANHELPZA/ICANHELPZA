import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FileText, Headphones, Music, GraduationCap, Check } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";
import { Link } from "wouter";

export function ServicesSection() {
  const { t } = useLanguage();

  const services = [
    {
      id: "cv-writing",
      title: t('services.cvWriting.title'),
      description: t('services.cvWriting.description'),
      icon: FileText,
      color: "gold",
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=200",
      features: ["Professional CV design", "Job search strategies", "Interview preparation"]
    },
    {
      id: "call-center",
      title: t('services.callCenter.title'),
      description: t('services.callCenter.description'),
      icon: Headphones,
      color: "blue",
      image: "https://images.unsplash.com/photo-1573497620053-ea5300f94f21?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=200",
      features: ["Virtual receptionist", "Customer support", "Multilingual service"]
    },
    {
      id: "music-mentoring",
      title: t('services.musicMentoring.title'),
      description: t('services.musicMentoring.description'),
      icon: Music,
      color: "purple",
      image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=200",
      features: ["Spotify & Apple Music uploads", "Cover art & promo design", "SAMRO registration help"]
    },
    {
      id: "academic-support",
      title: t('services.academicSupport.title'),
      description: t('services.academicSupport.description'),
      icon: GraduationCap,
      color: "green",
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&h=200",
      features: ["Homework assistance", "Subject tutoring", "Study strategies"]
    }
  ];

  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="services" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {t('services.title')}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('services.description')}
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service) => {
            const Icon = service.icon;
            const colorClasses = {
              gold: {
                bg: "bg-gold-100",
                text: "text-gold-600",
                border: "border-gold-500",
                button: "bg-gold-500 hover:bg-gold-600",
                check: "text-gold-500"
              },
              blue: {
                bg: "bg-blue-100",
                text: "text-blue-600", 
                border: "border-blue-500",
                button: "bg-blue-500 hover:bg-blue-600",
                check: "text-blue-500"
              },
              purple: {
                bg: "bg-purple-100",
                text: "text-purple-600",
                border: "border-purple-500", 
                button: "bg-purple-500 hover:bg-purple-600",
                check: "text-purple-500"
              },
              green: {
                bg: "bg-green-100",
                text: "text-green-600",
                border: "border-green-500",
                button: "bg-green-500 hover:bg-green-600", 
                check: "text-green-500"
              }
            }[service.color];

            return (
              <Card key={service.id} className={`shadow-lg hover:shadow-xl transition-shadow border-l-4 ${colorClasses.border}`}>
                <CardContent className="p-8">
                  <div className="flex items-start space-x-4">
                    <div className={`${colorClasses.bg} rounded-lg p-3`}>
                      <Icon className={`w-6 h-6 ${colorClasses.text}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-gray-900 mb-3">
                        {service.title}
                      </h3>
                      <p className="text-gray-600 mb-4">
                        {service.description}
                      </p>
                      <img 
                        src={service.image}
                        alt={service.title}
                        className="rounded-lg w-full h-32 object-cover mb-4" 
                      />
                      <ul className="space-y-2 text-sm text-gray-600 mb-4">
                        {service.features.map((feature, index) => (
                          <li key={index} className="flex items-center">
                            <Check className={`w-4 h-4 mr-2 ${colorClasses.check}`} />
                            {feature}
                          </li>
                        ))}
                      </ul>
                      <Button 
                        onClick={scrollToContact}
                        className={`${colorClasses.button} text-white font-semibold transition-colors`}
                      >
                        Book Consultation
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
