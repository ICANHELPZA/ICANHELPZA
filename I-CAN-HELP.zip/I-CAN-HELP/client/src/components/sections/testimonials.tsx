import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export function TestimonialsSection() {
  const { t } = useLanguage();

  const testimonials = [
    {
      name: "Thabo Mthembu",
      role: "Marketing Coordinator", 
      content: "I CAN HELP transformed my CV and job search strategy. Within 2 weeks of their assistance, I landed my dream marketing job in Johannesburg. Their expertise made all the difference!",
      initials: "TM",
      color: "gold"
    },
    {
      name: "Sarah Molefe",
      role: "Small Business Owner",
      content: "The call center services have been a game-changer for my boutique. Professional, multilingual support that makes my customers feel valued. Highly recommend for any growing business!",
      initials: "SM", 
      color: "blue"
    },
    {
      name: "Lerato Ndaba",
      role: "University Student",
      content: "Academic support from I CAN HELP improved my grades significantly. The personalized tutoring approach helped me understand complex concepts and boosted my confidence.",
      initials: "LN",
      color: "green"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real experiences from clients who achieved their goals with our support.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => {
            const colorClasses = {
              gold: "bg-gold-100 text-gold-600",
              blue: "bg-blue-100 text-blue-600",
              green: "bg-green-100 text-green-600"
            }[testimonial.color];

            return (
              <Card key={index} className="bg-white shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${colorClasses}`}>
                      <span className="font-bold text-lg">{testimonial.initials}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="flex text-gold-400 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic">
                    "{testimonial.content}"
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
