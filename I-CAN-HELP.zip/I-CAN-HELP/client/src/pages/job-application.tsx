import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { FileText, User, Phone, Mail, MapPin, GraduationCap, Briefcase, MessageCircle, Upload, Shield, Heart } from 'lucide-react';

const jobApplicationSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  idNumber: z.string().optional(),
  phoneNumber: z.string().min(10, 'Valid phone number is required'),
  email: z.string().email('Valid email is required'),
  address: z.string().min(3, 'Address is required'),
  education: z.string().min(1, 'Education level is required'),
  workExperience: z.string().optional(),
  skills: z.string().min(5, 'Please describe your skills'),
  languages: z.array(z.string()).min(1, 'Select at least one language'),
  jobSeeking: z.string().min(3, 'Job type is required'),
  currentlyEmployed: z.string().min(1, 'Employment status is required'),
  notes: z.string().optional(),
});

type JobApplicationFormData = z.infer<typeof jobApplicationSchema>;

const languages = [
  'English', 'IsiXhosa', 'IsiZulu', 'Afrikaans', 'Sesotho', 
  'Setswana', 'Sepedi', 'IsiNdebele', 'SiSwati', 'Tshivenda', 'Xitsonga'
];

const jobTypes = [
  'General work', 'Administration', 'Security', 'Driver', 'Retail',
  'Nanny/Childcare', 'Cleaner', 'Kitchen/Restaurant', 'Construction',
  'Gardening', 'Receptionist', 'Sales', 'Factory work', 'Other'
];

const educationLevels = [
  'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12 (Matric)',
  'N1-N3 Certificate', 'N4-N6 Diploma', 'NQF Level 4', 'NQF Level 5',
  'NQF Level 6', 'University Degree', 'Postgraduate', 'Other qualification'
];

export default function JobApplication() {
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [cvFile, setCvFile] = useState<File | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
    reset
  } = useForm<JobApplicationFormData>({
    resolver: zodResolver(jobApplicationSchema),
    defaultValues: {
      languages: []
    }
  });

  const submitApplication = useMutation({
    mutationFn: async (data: JobApplicationFormData & { photoFile?: File | null; cvFile?: File | null }) => {
      // For now, just submit the form data as JSON
      const submitData = {
        ...data,
        photoFile: undefined,
        cvFile: undefined,
      };
      
      const response = await fetch('/api/job-applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(submitData),
      });
      
      if (!response.ok) {
        throw new Error('Failed to submit application');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted Successfully!",
        description: "We'll review your application and contact you within 48 hours.",
      });
      reset();
      setSelectedLanguages([]);
      setPhotoFile(null);
      setCvFile(null);
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact us on WhatsApp.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: JobApplicationFormData) => {
    const formData = {
      ...data,
      languages: selectedLanguages,
      photoFile,
      cvFile
    };
    submitApplication.mutate(formData);
  };

  const toggleLanguage = (language: string) => {
    const updated = selectedLanguages.includes(language)
      ? selectedLanguages.filter(l => l !== language)
      : [...selectedLanguages, language];
    
    setSelectedLanguages(updated);
    setValue('languages', updated);
  };

  const openWhatsApp = () => {
    window.open('https://wa.me/27722402122?text=Hello, I need help with job applications', '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4 font-heading">
            Need a Job? Let's Help You!
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Submit your information and we'll create your professional CV and start the job hunt for you. 
            We help people from all over South Africa find employment opportunities.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Badge variant="secondary" className="px-4 py-2 bg-blue-100 text-blue-800">
              <Heart className="w-4 h-4 mr-2" />
              No experience? No problem!
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 bg-green-100 text-green-800">
              <Shield className="w-4 h-4 mr-2" />
              All languages supported
            </Badge>
            <Badge variant="secondary" className="px-4 py-2 bg-purple-100 text-purple-800">
              <MessageCircle className="w-4 h-4 mr-2" />
              WhatsApp support
            </Badge>
          </div>
        </div>

        <Card className="shadow-2xl border-0 rounded-3xl overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-8">
            <CardTitle className="text-3xl font-bold text-center font-heading">
              Job Application Form
            </CardTitle>
            <p className="text-center text-blue-100 mt-2">
              Fill in your details below - we'll handle the rest!
            </p>
          </CardHeader>
          
          <CardContent className="p-8 space-y-8">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              
              {/* Personal Information */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-gray-900 flex items-center font-heading">
                  <User className="w-6 h-6 mr-3 text-blue-600" />
                  Personal Information
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="fullName" className="text-sm font-semibold text-gray-700">
                      Full Name *
                    </Label>
                    <Input 
                      id="fullName"
                      placeholder="e.g. Sibusiso Mokoena"
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                      {...register('fullName')}
                    />
                    {errors.fullName && (
                      <p className="text-red-500 text-sm mt-1">{errors.fullName.message}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="idNumber" className="text-sm font-semibold text-gray-700">
                      ID Number (Optional)
                    </Label>
                    <Input 
                      id="idNumber"
                      placeholder="For CV and job applications"
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                      {...register('idNumber')}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phoneNumber" className="text-sm font-semibold text-gray-700 flex items-center">
                      <Phone className="w-4 h-4 mr-2" />
                      Phone Number (WhatsApp) *
                    </Label>
                    <Input 
                      id="phoneNumber"
                      placeholder="e.g. 072 123 4567"
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                      {...register('phoneNumber')}
                    />
                    {errors.phoneNumber && (
                      <p className="text-red-500 text-sm mt-1">{errors.phoneNumber.message}</p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-sm font-semibold text-gray-700 flex items-center">
                      <Mail className="w-4 h-4 mr-2" />
                      Email Address *
                    </Label>
                    <Input 
                      id="email"
                      type="email"
                      placeholder="We'll send your CV here"
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                      {...register('email')}
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="address" className="text-sm font-semibold text-gray-700 flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    Physical Address *
                  </Label>
                  <Input 
                    id="address"
                    placeholder="e.g. Khayelitsha, Cape Town (Town/Area is okay)"
                    className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                    {...register('address')}
                  />
                  {errors.address && (
                    <p className="text-red-500 text-sm mt-1">{errors.address.message}</p>
                  )}
                </div>
              </div>

              {/* Education & Experience */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-gray-900 flex items-center font-heading">
                  <GraduationCap className="w-6 h-6 mr-3 text-blue-600" />
                  Education & Experience
                </h3>
                
                <div>
                  <Label htmlFor="education" className="text-sm font-semibold text-gray-700">
                    Highest Grade Passed / Qualification *
                  </Label>
                  <Select onValueChange={(value) => setValue('education', value)}>
                    <SelectTrigger className="mt-2 h-12 rounded-xl border-2">
                      <SelectValue placeholder="Select your education level" />
                    </SelectTrigger>
                    <SelectContent>
                      {educationLevels.map((level) => (
                        <SelectItem key={level} value={level}>
                          {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.education && (
                    <p className="text-red-500 text-sm mt-1">{errors.education.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="workExperience" className="text-sm font-semibold text-gray-700 flex items-center">
                    <Briefcase className="w-4 h-4 mr-2" />
                    Work Experience (If Any)
                  </Label>
                  <Textarea 
                    id="workExperience"
                    placeholder="e.g. Cleaner at Shoprite, Feb 2022 – July 2023. Describe your duties and achievements."
                    className="mt-2 min-h-[100px] rounded-xl border-2 focus:border-blue-500"
                    {...register('workExperience')}
                  />
                </div>

                <div>
                  <Label htmlFor="skills" className="text-sm font-semibold text-gray-700">
                    Skills *
                  </Label>
                  <Textarea 
                    id="skills"
                    placeholder="e.g. Good with people, can clean, drive, cook, use a computer, customer service, etc."
                    className="mt-2 min-h-[100px] rounded-xl border-2 focus:border-blue-500"
                    {...register('skills')}
                  />
                  {errors.skills && (
                    <p className="text-red-500 text-sm mt-1">{errors.skills.message}</p>
                  )}
                </div>
              </div>

              {/* Languages */}
              <div className="space-y-4">
                <Label className="text-sm font-semibold text-gray-700">
                  Languages Spoken * (Select all that apply)
                </Label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {languages.map((language) => (
                    <div key={language} className="flex items-center space-x-2">
                      <Checkbox
                        id={language}
                        checked={selectedLanguages.includes(language)}
                        onCheckedChange={() => toggleLanguage(language)}
                        className="rounded-md"
                      />
                      <Label htmlFor={language} className="text-sm cursor-pointer">
                        {language}
                      </Label>
                    </div>
                  ))}
                </div>
                {errors.languages && (
                  <p className="text-red-500 text-sm">{errors.languages.message}</p>
                )}
              </div>

              {/* Job Preferences */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-gray-900 flex items-center font-heading">
                  <Briefcase className="w-6 h-6 mr-3 text-blue-600" />
                  Job Preferences
                </h3>
                
                <div>
                  <Label htmlFor="jobSeeking" className="text-sm font-semibold text-gray-700">
                    Job You Are Looking For *
                  </Label>
                  <Select onValueChange={(value) => setValue('jobSeeking', value)}>
                    <SelectTrigger className="mt-2 h-12 rounded-xl border-2">
                      <SelectValue placeholder="Select job type" />
                    </SelectTrigger>
                    <SelectContent>
                      {jobTypes.map((job) => (
                        <SelectItem key={job} value={job}>
                          {job}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.jobSeeking && (
                    <p className="text-red-500 text-sm mt-1">{errors.jobSeeking.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="currentlyEmployed" className="text-sm font-semibold text-gray-700">
                    Are you currently employed? *
                  </Label>
                  <Select onValueChange={(value) => setValue('currentlyEmployed', value)}>
                    <SelectTrigger className="mt-2 h-12 rounded-xl border-2">
                      <SelectValue placeholder="Select employment status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.currentlyEmployed && (
                    <p className="text-red-500 text-sm mt-1">{errors.currentlyEmployed.message}</p>
                  )}
                </div>
              </div>

              {/* File Uploads */}
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-gray-900 flex items-center font-heading">
                  <Upload className="w-6 h-6 mr-3 text-blue-600" />
                  Documents (Optional)
                </h3>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="photo" className="text-sm font-semibold text-gray-700">
                      Upload a Photo (Optional)
                    </Label>
                    <Input 
                      id="photo"
                      type="file"
                      accept="image/jpeg,image/png,image/jpg"
                      onChange={(e) => setPhotoFile(e.target.files?.[0] || null)}
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                    />
                    <p className="text-xs text-gray-500 mt-1">Passport-style photo - JPEG or PNG</p>
                  </div>
                  
                  <div>
                    <Label htmlFor="cv" className="text-sm font-semibold text-gray-700">
                      Upload CV/Certificates (Optional)
                    </Label>
                    <Input 
                      id="cv"
                      type="file"
                      accept=".pdf,.doc,.docx,image/*"
                      onChange={(e) => setCvFile(e.target.files?.[0] || null)}
                      className="mt-2 h-12 rounded-xl border-2 focus:border-blue-500"
                    />
                    <p className="text-xs text-gray-500 mt-1">PDF, DOC, or image files</p>
                  </div>
                </div>
              </div>

              {/* Additional Notes */}
              <div>
                <Label htmlFor="notes" className="text-sm font-semibold text-gray-700">
                  Any Notes or Questions for Us?
                </Label>
                <Textarea 
                  id="notes"
                  placeholder="Tell us anything else we should know, or ask any questions..."
                  className="mt-2 min-h-[100px] rounded-xl border-2 focus:border-blue-500"
                  {...register('notes')}
                />
              </div>

              {/* Submit Button */}
              <div className="text-center pt-6">
                <Button 
                  type="submit"
                  disabled={submitApplication.isPending}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-12 py-4 rounded-2xl font-bold text-lg shadow-xl transform hover:scale-105 transition-all duration-200"
                >
                  {submitApplication.isPending ? 'Submitting...' : 'Submit My Application'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <Card className="mt-8 bg-green-50 border-green-200 rounded-2xl">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <Shield className="w-8 h-8 text-green-600 mt-1" />
              <div>
                <h4 className="font-semibold text-green-800 mb-3">Your Information is Safe With Us</h4>
                <div className="space-y-2 text-sm text-green-700">
                  <p className="flex items-center">
                    <span className="text-green-500 mr-2">✅</span>
                    We protect your information and only use it to help you find work
                  </p>
                  <p className="flex items-center">
                    <span className="text-green-500 mr-2">✅</span>
                    We help people from all over South Africa - distance is not a problem
                  </p>
                  <p className="flex items-center">
                    <span className="text-green-500 mr-2">✅</span>
                    No experience? No school certificate? No problem – we'll help you too
                  </p>
                  <p className="flex items-center">
                    <span className="text-green-500 mr-2">💬</span>
                    Questions? 
                    <Button 
                      variant="link" 
                      onClick={openWhatsApp}
                      className="text-green-700 underline ml-1 p-0 h-auto"
                    >
                      WhatsApp us on 072 240 2122
                    </Button>
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}