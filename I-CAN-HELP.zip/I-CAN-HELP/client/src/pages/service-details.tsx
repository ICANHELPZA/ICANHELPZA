import { useRoute } from "wouter";
import { Navigation } from "@/components/layout/navigation";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, MessageCircle } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function ServiceDetails() {
  const [, params] = useRoute("/service/:serviceId");
  const { t } = useLanguage();
  
  const serviceId = params?.serviceId;

  const serviceDetails = {
    "cv-writing": {
      title: "CV Writing & Job Seeking Support",
      description: "Professional CV creation and comprehensive job search assistance to help you land your dream position in South Africa.",
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=600",
      features: [
        "Professional CV design and formatting",
        "Keyword optimization for ATS systems",
        "Cover letter writing",
        "LinkedIn profile optimization",
        "Job search strategy development",
        "Interview preparation coaching",
        "Salary negotiation guidance",
        "Follow-up strategies"
      ],
      process: [
        "Initial consultation to understand your goals",
        "Review of current CV and career history", 
        "Professional CV creation and design",
        "Job search strategy development",
        "Interview preparation sessions",
        "Ongoing support and guidance"
      ]
    },
    "call-center": {
      title: "Call Center Services",
      description: "Professional virtual receptionist and customer support services to enhance your business communication.",
      image: "https://images.unsplash.com/photo-1573497620053-ea5300f94f21?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=600",
      features: [
        "Virtual receptionist services",
        "Customer support and inquiries",
        "Appointment scheduling",
        "Order taking and processing",
        "Multilingual support (English, Xhosa, Afrikaans, Sesotho)",
        "Professional phone manner training",
        "Call handling and routing",
        "Customer relationship management"
      ],
      process: [
        "Business needs assessment",
        "Service customization and setup",
        "Staff training and integration",
        "Quality assurance protocols",
        "Performance monitoring",
        "Continuous improvement"
      ]
    },
    "music-mentoring": {
      title: "Music Mentoring & Career Development",
      description: "Comprehensive guidance for musicians looking to develop their skills and build successful careers in the music industry.",
      image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=600",
      features: [
        "Music career strategy development",
        "Performance coaching and stage presence",
        "Music production guidance",
        "Industry networking opportunities",
        "Brand development and marketing",
        "Recording and distribution advice",
        "Live performance opportunities",
        "Business aspects of music career"
      ],
      process: [
        "Musical goals and vision assessment",
        "Skill evaluation and development plan",
        "Industry introduction and networking",
        "Performance and recording opportunities",
        "Career milestone tracking",
        "Ongoing mentorship and support"
      ]
    },
    "academic-support": {
      title: "Academic Support & Tutoring",
      description: "Personalized academic assistance to help students excel in their studies and achieve educational goals.",
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&h=600",
      features: [
        "Subject-specific tutoring",
        "Homework assistance and guidance",
        "Study skills development",
        "Exam preparation strategies",
        "Research and writing support",
        "Time management coaching",
        "Academic goal setting",
        "Progress tracking and reporting"
      ],
      process: [
        "Academic assessment and goal setting",
        "Customized learning plan development",
        "Regular tutoring sessions",
        "Progress monitoring and adjustments",
        "Study strategy implementation",
        "Ongoing academic support"
      ]
    }
  };

  const service = serviceId ? serviceDetails[serviceId as keyof typeof serviceDetails] : null;

  if (!service) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <Card>
            <CardContent className="p-16 text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Service Not Found</h1>
              <p className="text-gray-600">The requested service could not be found.</p>
            </CardContent>
          </Card>
        </div>
        <Footer />
      </div>
    );
  }

  const openWhatsApp = () => {
    const phoneNumber = "+27722402122";
    const message = `Hi! I'm interested in your ${service.title} service from I CAN HELP website.`;
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const scrollToContact = () => {
    window.location.href = "/#contact";
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-gray-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1 className="text-5xl font-bold text-gray-900 leading-tight">
                {service.title}
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                {service.description}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  onClick={scrollToContact}
                  className="bg-gold-500 hover:bg-gold-600 text-black px-8 py-4 rounded-lg font-semibold text-lg"
                >
                  Book Consultation
                </Button>
                <Button 
                  onClick={openWhatsApp}
                  variant="outline"
                  className="border-2 border-gold-500 text-gold-600 hover:bg-gold-50 px-8 py-4 rounded-lg font-semibold text-lg"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Chat on WhatsApp
                </Button>
              </div>
            </div>
            <div>
              <img 
                src={service.image}
                alt={service.title}
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-16">
            What's Included
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {service.features.map((feature, index) => (
              <div key={index} className="flex items-start space-x-3">
                <Check className="w-6 h-6 text-gold-500 mt-1 flex-shrink-0" />
                <span className="text-gray-700 text-lg">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 text-center mb-16">
            Our Process
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {service.process.map((step, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-gold-500 text-black rounded-full flex items-center justify-center font-bold text-xl mx-auto mb-4">
                    {index + 1}
                  </div>
                  <p className="text-gray-700">{step}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gold-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Contact us today to learn more about how our {service.title.toLowerCase()} can help you achieve your goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={scrollToContact}
              className="bg-gold-500 hover:bg-gold-600 text-black px-8 py-4 rounded-lg font-semibold text-lg"
            >
              Book Consultation
            </Button>
            <Button 
              onClick={openWhatsApp}
              variant="outline"
              className="border-2 border-gold-500 text-gold-600 hover:bg-gold-50 px-8 py-4 rounded-lg font-semibold text-lg"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat on WhatsApp
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
