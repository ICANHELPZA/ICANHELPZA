export type Language = 'en' | 'xh' | 'af' | 'st';

export interface Translations {
  [key: string]: string | Translations;
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      services: "Services",
      pricing: "Pricing",
      testimonials: "Testimonials",
      contact: "Contact"
    },
    hero: {
      title: "I CAN HELP Your Success Story",
      subtitle: "Professional services for job seekers, businesses, musicians, and students across South Africa. From CV writing to call center support, we're here to help you succeed.",
      exploreServices: "Explore Services",
      chatWhatsApp: "Chat on WhatsApp"
    },
    services: {
      title: "Our Professional Services",
      description: "We provide comprehensive support across multiple areas to help you achieve your goals. Each service is tailored to meet your specific needs.",
      cvWriting: {
        title: "CV Writing & Job Seeking",
        description: "Professional CV creation, job application assistance, and interview preparation to help you land your dream job in South Africa."
      },
      callCenter: {
        title: "Call Center Services", 
        description: "Virtual receptionist and customer support services to help your business maintain professional communication with clients."
      },
      musicMentoring: {
        title: "I CAN HELP Musicians",
        description: "Independent music distribution & artist support. Get your music on Spotify, Apple Music & YouTube via WhatsApp. No laptop, no label, no stress."
      },
      academicSupport: {
        title: "Learner Support Packages",
        description: "Affordable, flexible packages designed for real results. From homework help to full academic support with live tutoring sessions."
      }
    },
    pricing: {
      title: "Transparent Pricing",
      description: "Affordable rates designed to make professional services accessible to everyone in South Africa.",
      weekly: "Weekly Support",
      monthly: "Monthly Package",
      custom: "Custom Solution"
    },
    contact: {
      title: "Get Started Today",
      description: "Ready to take the next step? Contact us through any of these convenient methods.",
      form: {
        firstName: "First Name",
        lastName: "Last Name", 
        email: "Email Address",
        phone: "Phone Number",
        service: "Service Needed",
        language: "Preferred Language",
        message: "Message",
        submit: "Book Consultation"
      }
    }
  },
  xh: {
    nav: {
      services: "Iinkonzo",
      pricing: "Amaxabiso",
      testimonials: "Ubungqina",
      contact: "Qhagamshelana"
    },
    hero: {
      title: "NDIYAKUNCEDA Ibali Lakho Lempumelelo",
      subtitle: "Iinkonzo zobugcisa kubafuna umsebenzi, amashishini, iimvumi, nabafundi kuMzantsi Afrika. Ukusuka ekubhaleni i-CV ukuya kwinkxaso yecall center, silapha ukukunceda uphumelele.",
      exploreServices: "Phonononga Iinkonzo",
      chatWhatsApp: "Ncokola ku-WhatsApp"
    },
    services: {
      title: "Iinkonzo Zethu Zobugcisa",
      description: "Sibonelela ngenkxaso ebanzi kwiindawo ezininzi ukukunceda ufikelele kwiinjongo zakho. Inkonzo nganye yenziwe ngokwemfuno zakho ezikhethekileyo.",
      cvWriting: {
        title: "Ukubhala i-CV Nokufuna Umsebenzi",
        description: "Ukwenziwa kwe-CV ngobugcisa, uncedo lwisicelo somsebenzi, kunye nokulungiselela udliwano-ndlebe ukukunceda ufumane umsebenzi wakho wamaphupha eMzantsi Afrika."
      },
      callCenter: {
        title: "Iinkonzo ze-Call Center",
        description: "Inkonzo yommeli wentsapho kunye nenkxaso yabathengi ukukunceda ishishini lakho ligcine unxibelelwano lobugcisa nabathengi."
      },
      musicMentoring: {
        title: "Ukuqeqesha Umculo",
        description: "Isikhokelo nenkxaso kwiimvumi ezijonga ukuphuhlisa izakhono zazo, zakhe imisebenzi yazo, kwaye zikhangele kushishino lomculo."
      },
      academicSupport: {
        title: "Inkxaso Yezemfundo",
        description: "Uncedo lwesixeko, ukuqeqesha, nesikhokelo semfundo kubafundi bawo onke amanqanaba ukuphucula iziphumo zabo zemfundo."
      }
    },
    pricing: {
      title: "Amaxabiso Acacileyo",
      description: "Amazinga angabizi kakhulu enzelwe ukwenza iinkonzo zobugcisa zifikeleleke kuye wonke umntu eMzantsi Afrika.",
      weekly: "Inkxaso Yeveki",
      monthly: "Iphakheji Yenyanga",
      custom: "Isixazululo Esikhethekileyo"
    },
    contact: {
      title: "Qala Namhlanje",
      description: "Ukulungele ukuthatha inyathelo elilandelayo? Qhagamshelana nathi ngayiphi na kweezi ndlela zifanelekileyo.",
      form: {
        firstName: "Igama Lokuqala",
        lastName: "Ifani",
        email: "Idilesi ye-imeyile",
        phone: "Inombolo Yefoni",
        service: "Inkonzo Efunekayo",
        language: "Ulwimi Olukhetha Lo",
        message: "Umyalezo",
        submit: "Bhuka Ingxoxo"
      }
    }
  },
  af: {
    nav: {
      services: "Dienste",
      pricing: "Pryse",
      testimonials: "Getuienisse",
      contact: "Kontak"
    },
    hero: {
      title: "EK KAN HELP Jou Suksesverhaal",
      subtitle: "Professionele dienste vir werksoekers, besighede, musikante en studente regoor Suid-Afrika. Van CV-skryf tot oproepsentrum-ondersteuning, ons is hier om jou te help slaag.",
      exploreServices: "Verken Dienste",
      chatWhatsApp: "Gesels op WhatsApp"
    },
    services: {
      title: "Ons Professionele Dienste",
      description: "Ons bied omvattende ondersteuning oor verskeie areas om jou te help om jou doelwitte te bereik. Elke diens is aangepas om jou spesifieke behoeftes te voldoen.",
      cvWriting: {
        title: "CV Skryf & Werksoek",
        description: "Professionele CV-skepping, werksoekingshulp en onderhoudvoorbereiding om jou te help om jou droomwerk in Suid-Afrika te kry."
      },
      callCenter: {
        title: "Oproepsentrum Dienste",
        description: "Virtuele resepsioniste en kliëntediens om jou besigheid te help om professionele kommunikasie met kliënte te handhaaf."
      },
      musicMentoring: {
        title: "Musiek Mentorskap",
        description: "Leiding en ondersteuning vir musikante wat hul vaardighede wil ontwikkel, hul loopbane bou en die musiekben navigeer."
      },
      academicSupport: {
        title: "Akademiese Ondersteuning",
        description: "Huiswerkhulp, tutoring en akademiese leiding vir studente van alle vlakke om hul opvoedkundige uitkomste te verbeter."
      }
    },
    pricing: {
      title: "Deursigtige Pryse",
      description: "Bekostigbare tariewe ontwerp om professionele dienste toeganklik te maak vir almal in Suid-Afrika.",
      weekly: "Weeklikse Ondersteuning",
      monthly: "Maandelikse Pakket",
      custom: "Pasgemaakte Oplossing"
    },
    contact: {
      title: "Begin Vandag",
      description: "Gereed om die volgende stap te neem? Kontak ons deur enige van hierdie gerieflike metodes.",
      form: {
        firstName: "Voornaam",
        lastName: "Van",
        email: "E-pos Adres",
        phone: "Telefoonnommer",
        service: "Diens Benodig",
        language: "Voorkeur Taal",
        message: "Boodskap",
        submit: "Bespreek Konsultasie"
      }
    }
  },
  st: {
    nav: {
      services: "Ditsebeletso",
      pricing: "Ditheko",
      testimonials: "Dipaki",
      contact: "Ikopanye"
    },
    hero: {
      title: "KE KA THUSA Pale ea Hao ea Katleho",
      subtitle: "Ditshebeletso tsa setsebi bakeng sa bafuputsi ba mosebetsi, likhoebo, bahlabi ba mmino le baithuti ho pota Afrika Boroa. Ho tloha ho ngoleng CV ho ea ho tshebetso ea call center, re teng ho u thusa hore u atlehe.",
      exploreServices: "Hlahloba Litshebeletso",
      chatWhatsApp: "Buisana ho WhatsApp"
    },
    services: {
      title: "Ditshebeletso Tsa Rona Tsa Setsebi",
      description: "Re fana ka tshebetso e pharaletseng libakeng tse fapa-fapaneng ho u thusa ho fihlela lipakane tsa hao. Tshebeletso e nngwe le e nngwe e etselitsoe ho fihlela litlhoko tsa hao tse khethehileng.",
      cvWriting: {
        title: "Ho Ngola CV le Ho Batla Mosebetsi",
        description: "Ho theoa ha CV ka botsebi, thuso ea kopo ea mosebetsi, le ho itokisetsa dipuisano ho u thusa ho fumana mosebetsi oa hao oa ditoro Afrika Boroa."
      },
      callCenter: {
        title: "Ditshebeletso tsa Call Center",
        description: "Moemeli ea bohloko le ditshebeletso tsa tshebetso ea bareki ho thusa khoebo ea hao ho boloka puisano ea setsebi le bareki."
      },
      musicMentoring: {
        title: "Thupello ea Mmino",
        description: "Tataiso le tshebetso bakeng sa bahlabi ba mmino ba batlang ho hlahisa meharo ea bona, ho aha mesebetsi ea bona, le ho tsamaea indastering ea mmino."
      },
      academicSupport: {
        title: "Tshebetso ea Thuto",
        description: "Thuso ea mosebetsi oa lapeng, thupello, le tataiso ea thuto bakeng sa baithuti ba maemo ohle ho ntlafatsa diphetho tsa bona tsa thuto."
      }
    },
    pricing: {
      title: "Litheko Tse Hlakileng",
      description: "Litekanyetso tse theko e tlaase tse etselitsoeng ho etsa ditshebeletso tsa setsebi ho fihlella batho bohle Afrika Boroa.",
      weekly: "Tshebetso ea Beke",
      monthly: "Sephutheloana sa Kgwedi",
      custom: "Tharollo e Khethehileng"
    },
    contact: {
      title: "Qala Kajeno",
      description: "U se u loketse ho nka mohato o latelang? Ikopanye le rona ka e nngwe ea tsela tsena tse bonolo.",
      form: {
        firstName: "Lebitso la Pele",
        lastName: "Lebitso la Morao",
        email: "Aterese ea Imeile",
        phone: "Nomoro ea Mohala",
        service: "Tshebeletso e Hlokahalang",
        language: "Puo e Kgethwang",
        message: "Molaetsa",
        submit: "Buisa Letebello"
      }
    }
  }
};

export const languageNames: Record<Language, string> = {
  en: "English",
  xh: "Xhosa",
  af: "Afrikaans",
  st: "Sesotho"
};
