# replit.md

## Overview

This is a full-stack web application for "I CAN HELP", a professional services business offering CV writing, call center services, music mentoring, and academic support across South Africa. The application is built with a modern React frontend and Express.js backend, featuring multilingual support and a comprehensive contact system.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type safety
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight alternative to React Router)
- **TanStack Query** for server state management and data fetching
- **Tailwind CSS** with **shadcn/ui** components for styling
- **React Hook Form** with **Zod** validation for form handling

### Backend Architecture
- **Express.js** with TypeScript for API endpoints
- **RESTful API** design with proper error handling
- **In-memory storage** with interface for easy database migration
- **Drizzle ORM** configured for PostgreSQL (ready for database integration)

### Key Design Decisions
1. **Monorepo Structure**: Client, server, and shared code in a single repository for easier development
2. **TypeScript Throughout**: End-to-end type safety with shared schemas
3. **Component-Based UI**: Reusable shadcn/ui components with consistent design system
4. **Internationalization Ready**: Built-in support for multiple South African languages (English, Xhosa, Afrikaans, Sesotho)

## Key Components

### Frontend Components
- **Navigation**: Responsive navigation with language selector and mobile menu
- **Hero Section**: Landing page with call-to-action buttons
- **Services Section**: Showcase of four main service offerings
- **Pricing Section**: Transparent pricing with multiple plan options
- **Contact Section**: Multi-step contact form with service selection
- **WhatsApp Integration**: Floating WhatsApp button for instant communication

### Backend API Endpoints
- `POST /api/inquiries` - Submit contact form inquiries
- `GET /api/inquiries` - Retrieve all inquiries (admin functionality)
- `PATCH /api/inquiries/:id/status` - Update inquiry status

### Shared Schema
- **User Schema**: Basic user structure for future authentication
- **Inquiry Schema**: Contact form data structure with validation
- **Zod Validation**: Type-safe form validation schemas

## Data Flow

1. **User Interaction**: Users navigate the multilingual website and submit contact forms
2. **Form Submission**: Contact forms are validated client-side with Zod schemas
3. **API Communication**: TanStack Query handles API requests with proper error handling
4. **Data Storage**: Currently uses in-memory storage with easy database migration path
5. **Real-time Updates**: Toast notifications provide user feedback

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, React DOM, React Hook Form)
- Vite for development and building
- Express.js for backend API
- TypeScript for type safety

### UI and Styling
- Tailwind CSS for utility-first styling
- Radix UI primitives for accessible components
- Lucide React for consistent iconography
- Class Variance Authority for component variants

### Database and Validation
- Drizzle ORM with PostgreSQL dialect
- Zod for schema validation
- @neondatabase/serverless for database connection

### Development Tools
- ESBuild for server bundling
- PostCSS with Autoprefixer
- Replit-specific development plugins

## Deployment Strategy

### Development Environment
- Vite dev server with HMR for frontend development
- Express server with TypeScript compilation via tsx
- Integrated development with shared TypeScript configuration

### Production Build
1. **Frontend**: Vite builds optimized React application to `dist/public`
2. **Backend**: ESBuild bundles server code to `dist/index.js`
3. **Static Serving**: Express serves built frontend files in production

### Environment Configuration
- `NODE_ENV` for environment detection
- `DATABASE_URL` for PostgreSQL connection (when database is added)
- WhatsApp integration via environment variables

### Database Migration Path
- Drizzle configuration ready for PostgreSQL
- Schema defined in `shared/schema.ts`
- Migration commands configured (`db:push`)
- Current in-memory storage easily replaceable with database implementation

## Changelog
- July 06, 2025. Initial setup
- July 06, 2025. Added PostgreSQL database integration with Drizzle ORM
- July 06, 2025. Updated contact details: WhatsApp +27722402122, Email icanhelpza@gmail.com
- July 06, 2025. Added comprehensive learner support packages (Homework Hero, Smart Learner, Exam Booster, All-in Scholar)
- July 06, 2025. Added "Tutor on Standby" service (R40/session) and tutor recruitment system
- July 06, 2025. Integrated comprehensive "I CAN HELP Musicians" distribution service with 3 packages (R300-R1500)
- July 06, 2025. Added comprehensive job application system with professional form design and database storage
- July 06, 2025. Updated business monthly plan to R6000, added modern typography (Poppins/Roboto)

## Recent Changes

### Learner Support Services Expansion
- Added 4 learner support package tiers ranging from R100-R500 per week
- Integrated "Tutor on Standby" service for urgent help (R40 per 20-minute session)
- Added tutor recruitment system for freelance educators
- Multi-language support for tutoring (English, Xhosa, Zulu, Afrikaans)
- Live tutoring sessions with follow-up feedback to parents
- Updated contact form to include all new learner service options

### Database Integration
- Migrated from in-memory storage to PostgreSQL database
- All inquiries now persistently stored in database
- Maintained same API interface for seamless integration

### Music Distribution Services Integration
- Added "I CAN HELP Musicians" comprehensive service with 3 main packages:
  - Starter Package (R300): Single song upload with cover art
  - Artist Pro Package (R600): Up to 3 tracks with full support
  - Label Starter (R1500): Multi-artist monthly service
- Integrated 5 add-on services (SAMRO registration, Spotify setup, etc.)
- WhatsApp-based music distribution targeting kasi and independent artists
- Purple branding scheme for music services to differentiate from other offerings

### Job Application System
- Added comprehensive job application form with modern gradient design
- 15+ form fields including personal info, education, experience, skills, languages
- Multi-language support (11 South African languages)
- File upload support for photos and CV documents
- Professional styling with Poppins/Roboto typography
- Database storage with full CRUD operations
- Admin dashboard capability for application management
- WhatsApp integration for immediate support

### Contact Information Updates
- WhatsApp: +27 72 240 2122 (integrated across all components)
- Email: icanhelpza@gmail.com (updated in footer and contact sections)

## User Preferences

Preferred communication style: Simple, everyday language.
Contact details: WhatsApp 0722402122, Email icanhelpza@gmail.com